package models;

import java.util.Date;

import io.ebean.*;
import javax.persistence.*;

import play.data.validation.Constraints.*;

@Entity
public class Jeu extends Model{
  
    private static final long serialVersionUID = 1L; 
    
    @Id
    private long id;
    
    @Required
    @Pattern(value="^[A-Z][a-z0-9 ]{2,}", message="le titre doit commencer par une majusucule")
   
    private String titre;
    private int age;
   
    
    public Jeu(){
        this.titre="fifa";
        this.age=3;
        
    }
    
    public String getTitre(){
        return this.titre;
    }
    
    public void setTitre(String titre){
        this.titre = titre;
    } 
    public int getAge(){
        return age;
    }
    public void setAge(int age){
        this.age = age;
    }
    
    public void setId(Long id){
        this.id = id;
    }
    
    public Long getId(){
        return this.id;
    }
    
    public static Finder<Long,Jeu> find = new Finder<Long,Jeu>(Jeu.class);
    
}